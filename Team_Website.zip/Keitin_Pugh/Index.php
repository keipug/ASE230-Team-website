<?php
$team = [
    [
        'name' => 'Keitin Pugh', 
        'role' => 'Project Manager', 
        'image' => 'assets/images/Keitin.jpg',
        'experience' => [
			['company' => 'Meijer', 'position' => 'General Merchandise Store Associate', 'time' => '2023 - Present', 'summary_of_job' => 'My job as store associate is to straighten shelves and assist customers.']
		],
        'dob' => '2004-08-30',
        'email' => 'keitinpugh@outlook.com',
		'phone' => '8593080991',
		'linkedin' => 'https://www.linkedin.com/in/keitin-pugh/',
		'github' => 'https://github.com/keipug/work.git',
		'school' => 'https://www.nku.edu/'
    ],
    [
        'name' => 'Matthew Miles', 
        'role' => 'Lead Developer', 
        'image' => 'assets/images/MatthewakaMM.jpg',
        'experience' => [
			['company' => 'McDonalds', 'position' => 'Fry Cook', 'time' => '2020 - 2021', 'summary_of_job' => 'Fullfill Custom Orders in a timely fashion.'],
			['company' => 'Fidelity', 'position' => 'Data Entry', 'time' => '2021 - Present', 'summary_of_job' => 'Enter data into spreadsheets using common data entry tools.'],
		],
        'dob' => '2004-03-16',
        'email' => 'MatthewMiles@outlook.com',
		'phone' => '8596924203',
		'linkedin' => 'https://www.linkedin.com/in/Matthew-Miles/',
		'github' => 'https://github.com/MM/work.git',
		'school' => 'https://www.nku.edu/'
    ],
    [
        'name' => 'Owen McCormick', 
        'role' => 'Designer', 
        'image' => 'assets/images/OwenTheLegendMcCormick.jpg',
        'experience' => [
			['company' => 'Encore', 'position' => 'Sales Associate', 'time' => '2023 - Present', 'summary_of_job' => 'Call companies and sell them space on our cloud server.']
		],
        'dob' => '2002-10-22',
        'email' => 'OwenMcCormick@outlook.com',
		'phone' => '8593653609',
		'linkedin' => 'https://www.linkedin.com/in/Owen-McCormick/',
		'github' => 'https://github.com/OthelegendM/work.git',
		'school' => 'https://www.nku.edu/'
    ]
];
$now = new DateTime();
function age($dob, $currentday){
    $dobObject = new DateTime($dob);
    $ageDifference = $currentday->diff($dobObject);
    $age = $ageDifference->y;
    return $age;
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo "Our Amazing Team:"?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
</head>
<body>
    <article class="resume-wrapper text-center position-relative">
        <div class="resume-wrapper-inner mx-auto text-start bg-white shadow-lg">
            <h1 class="py-4 text-center"><?php echo "OUR AMAZING TEAM"?></h1>
            <?php foreach ($team as $index => $member) { ?>
                <header class="resume-header pt-4 pt-md-0">
                    <div class="row">
                        <div class="col-block col-md-auto resume-picture-holder text-center text-md-start">
                            <img class="picture" src="<?php echo $member['image']; ?>" alt="<?php echo $member['name']; ?>">
                        </div>
                        <div class="col">
                            <div class="row p-4 justify-content-center justify-content-md-between">
                                <div class="primary-info col-auto">
                                    <h1 class="name mt-0 mb-1 text-white text-uppercase"><?php echo $member['name']; ?></h1>
                                    <div class="title mb-3"><?php echo $member['role']; ?></div>
                                    <div class="title mb-3"><?php echo age($member['dob'],$now); ?></div>
                                    <div class="title mb-3"><?php echo renderMemberProfile($member); ?></div>
                                    <?php foreach ($member['experience'] as $experience => $e): ?>
                                        <div class="title mb-3"><?php echo workexperience($e); ?></div>
                                    <?php endforeach; ?>
                                    <a href="Keitin_Pugh.php?member=<?php echo $index; ?>" class="btn btn-secondary"><?php echo "See full profile"?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
            <?php } ?>
        </div>
    </article>
</body>
</html>
<?php
function renderMemberProfile($member) {
    ob_start();
    ?>
	<a class="text-link" href="<?php echo $member['email']; ?>"><i class="far fa-envelope fa-fw me-2" data-fa-transform="grow-3"></i><?php echo $member['email']; ?></a>
	<a class="text-link" href="tel:+<?php echo $member['phone']; ?>"><i class="fas fa-mobile-alt fa-fw me-2" data-fa-transform="grow-6"></i><?php echo $member['phone']; ?></a>
    <a class="text-link" href="<?php echo $member['linkedin']; ?>"><span class="fa-container text-center me-2"><i class="fab fa-linkedin-in fa-fw"></i></span><?php echo $member['linkedin']; ?></a>
	<a class="text-link" href="<?php echo $member['github']; ?>"><span class="fa-container text-center me-2"><i class="fab fa-github-alt fa-fw"></i></span><?php echo $member['github']; ?></a>
	<a class="text-link" href="<?php echo $member['name']; ?>"><span class="fa-container text-center me-2"><i class="fas fa-globe"></i></span><?php echo $member['school']; ?></a>
    <?php
    return ob_get_clean();
};
function workexperience($experience) {
    ob_start();
    ?>
	<h3 class="resume-position-title font-weight-bold mb-1"><?php echo $experience['position']; ?></h3>
	<div class="resume-company-name ms-auto"><?php echo $experience['company']; ?></div>
	<div class="resume-position-time"><?php echo $experience['time']; ?></div>
	<?php echo $experience['summary_of_job']; ?>
    <?php
    return ob_get_clean();
}
?>
