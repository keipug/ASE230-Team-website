<?php
$team = [
	[
		'name' => 'Keitin Pugh',
		'dob' => '2004-08-30',
		'job' => 'Information Security Analyst',
		'img' => 'assets/images/Keitin.jpg',
		'email' => 'keitinpugh@outlook.com',
		'phone' => '8593080991',
		'linkedin' => 'https://www.linkedin.com/in/keitin-pugh/',
		'github' => 'https://github.com/keipug/work.git',
		'school' => 'https://www.nku.edu/',
		'summary' => 'I currently attend Northern Kentucky University and am pursuing a bachelors degree in cybersecurity. I volunteered at Pendleton County School District where I job shadowed the network administrator. I mostly focus on how machanical learning and AI can effect cybersecurity.',
		'experience' => [
			['company' => 'Meijer', 'position' => 'General Merchandise Store Associate', 'time' => '2023 - Present', 'summary_of_job' => 'My job as store associate is to straighten shelves and assist customers.']
		],
		'skills' => [
			'Network Diagnostic Tools',
			'Penetration Testing'
		],
		'os' => [
			'Java',
			'Python',
			'JavaScript'
		],
		'education' => 'Pursuing Bachelors Degree in Cybersecurity',
		'edulocation' => 'Northern Kentucky University',
		'edu_time_period' => '2022 - 2025',
		'lang' => [
			'English'
		],
		'awards' => [
			['name' => 'Safety Member of the Month', 'description' => 'Award given for my compliance with safety regulations.']
		],
		'interest' => [
			'Powerlifting', 'Cooking', 'Baking'
		],
		'projects' => [
			['name' => 'Trig Mathmatical', 'description' => 'This first project was a website called trigmathmatical which had the goal of helping students understand basic trigenometry.', 'link_name' => 'Go to link', 'link' => 'http://localhost/Keitin_Pugh/assets/Trig/Trig_Mathematical.html', 'img' => 'assets/images/trig.jpg']
		]
	],
	[
		'name' => 'Matthew Miles',
		'dob' => '2004-03-16',
		'job' => 'Computer Analytics',
		'img' => 'assets/images/MatthewakaMM.jpg',
		'email' => 'MatthewMiles@outlook.com',
		'phone' => '8596924203',
		'linkedin' => 'https://www.linkedin.com/in/Matthew-Miles/',
		'github' => 'https://github.com/MM/work.git',
		'school' => 'https://www.nku.edu/',
		'summary' => 'I am a student at NKU and I study computer analytics. I like playing the drums.',
		'skills' => [
			'Computer Analysis',
			'Historical Knowledge on Technology',
			'Coding'
		],
		'os' => [
			'Java',
			'JavaScript'
		],
		'education' => 'Pursuing Bachelors Degree in Computer Science',
		'edulocation' => 'Northern Kentucky University',
		'edu_time_period' => '2022 - 2026',
		'lang' => [
			'English', 'French'
		],
		'experience' => [
			['company' => 'McDonalds', 'position' => 'Fry Cook', 'time' => '2020 - 2021', 'summary_of_job' => 'Fullfill Custom Orders in a timely fashion.'],
			['company' => 'Fidelity', 'position' => 'Data Entry', 'time' => '2021 - Present', 'summary_of_job' => 'Enter data into spreadsheets using common data entry tools.'],
		],
		'awards' => [
			['name' => 'Best in Office', 'description' => 'Award given for showing up on time every day.'],
			['name' => 'Computer Analyst of the Year', 'description' => 'Having the highest performance in my department.']
		],
		'interest' => [
			'Powerlifting', 'Gaming'
		],
		'projects' => [
			['name' => 'Hi1', 'description' => 'HTML page that says Hi.', 'link_name' => 'Go to link', 'link' => 'http://localhost/Keitin_Pugh/assets/Bye/Hi1.html', 'img' => 'assets/images/Hi1.jpg'],
			['name' => 'Hi2', 'description' => 'HTML page that says hi again.', 'link_name' => 'Go to link', 'link' => 'http://localhost/Keitin_Pugh/assets/Bye/Hi2.html', 'img' => 'assets/images/Hi2.jpg']
		]
	],
	[
		'name' => 'Owen McCormick',
		'dob' => '2002-10-22',
		'job' => 'Network Engineer',
		'img' => 'assets/images/OwenTheLegendMcCormick.jpg',
		'email' => 'OwenMcCormick@outlook.com',
		'phone' => '8593653609',
		'linkedin' => 'https://www.linkedin.com/in/Owen-McCormick/',
		'github' => 'https://github.com/OthelegendM/work.git',
		'school' => 'https://www.nku.edu/',
		'summary' => 'I attended NKU and study network engineering. I enjoy playing the bass.',
		'skills' => [
			'Network Topology',
			'Network Scanning'
		],
		'os' => [
			'Java',
		],
		'education' => 'Pursuing Associate Degree in Comp Sci',
		'edulocation' => 'Northern Kentucky University',
		'edu_time_period' => '2022 - 2023',
		'lang' => [
			'English', 'German', 'Latin'
		],
		'awards' => [
			['name' => 'Employee of the Month', 'description' => 'Most recommendations from manager.'],
			['name' => 'Attendance Award', 'description' => 'Showing up to work on time every day.'],
			['name' => 'Dance Dance', 'description' => 'Best dancer at employee function.'],
		],
		'experience' => [
			['company' => 'Encore', 'position' => 'Sales Associate', 'time' => '2023 - Present', 'summary_of_job' => 'Call companies and sell them space on our cloud server.']
		],
		'interest' => [
			'Gaming'
		],
		'projects' => [
			['name' => 'Bye1', 'description' => 'HTML page that says bye.', 'link_name' => 'Go to link', 'link' => 'http://localhost/Keitin_Pugh/assets/Bye/Bye1.html', 'img' => 'assets/images/Bye1.jpg'],
			['name' => 'Bye2', 'description' => 'HTML page that says bye again.', 'link_name' => 'Go to link', 'link' => 'http://localhost/Keitin_Pugh/assets/Bye/Bye2.html', 'img' => 'assets/images/Bye2.jpg'],
			['name' => 'Bye3', 'description' => 'HTML page that also says bye.', 'link_name' => 'Go to link', 'link' => 'http://localhost/Keitin_Pugh/assets/Bye/Bye3.html', 'img' => 'assets/images/Bye3.jpg']
		]
	]
];
// Get the member ID from the URL
$memberId = isset($_GET['member']) ? (int)$_GET['member'] : 0;

// Ensure the ID is valid
if (!isset($team[$memberId])) {
    echo "Member not found!";
    exit;
}

// Get the selected team member's information
$member = $team[$memberId];
$now = new DateTime();
function age($dob, $currentday){
    $dobObject = new DateTime($dob);
    $ageDifference = $currentday->diff($dobObject);
    $age = $ageDifference->y;
    return $age;
};
?>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <title><?php echo $member['name']; ?><?php echo '\'s Resume'; ?></title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Your name's resume">
    <meta name="author" content="Keitin Pugh">    
    <link rel="shortcut icon" href="favicon.ico"> 
    
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    
    <!-- FontAwesome JS-->
	<script defer src="assets/fontawesome/js/all.min.js"></script>
       
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/pillar-1.css">


</head> 

<body>
    <article class="resume-wrapper text-center position-relative">
	    <div class="resume-wrapper-inner mx-auto text-start bg-white shadow-lg">
		    <header class="resume-header pt-4 pt-md-0">
			    <div class="row">
				    <div class="col-block col-md-auto resume-picture-holder text-center text-md-start">
				        <img class="picture" src="<?php echo $member['img'];?>" alt="">
				    </div><!--//col-->
				    <div class="col">
					    <div class="row p-4 justify-content-center justify-content-md-between">
						    <div class="primary-info col-auto">
							    <h1 class="name mt-0 mb-1 text-white text-uppercase text-uppercase"><?php echo $member['name']; ?></h1>
							    <div class="title mb-2"><?php echo $member['job']?></div>
								<div class="title mb-2"><?php echo age($member['dob'],$now);?></div>
							    <ul class="list-unstyled">
								    <li class="mb-2"><a class="text-link" href="<?php echo $member['email']; ?>"><i class="far fa-envelope fa-fw me-2" data-fa-transform="grow-3"></i><?php echo $member['email']; ?></a></li>
								    <li><a class="text-link" href="tel:+<?php echo $member['phone']; ?>"><i class="fas fa-mobile-alt fa-fw me-2" data-fa-transform="grow-6"></i><?php echo $member['phone']; ?></a></li>
							    </ul>
						    </div><!--//primary-info-->
						    <div class="secondary-info col-auto mt-2">
							    <ul class="resume-social list-unstyled">
					                <li class="mb-3"><a class="text-link" href="<?php echo $member['linkedin']; ?>"><span class="fa-container text-center me-2"><i class="fab fa-linkedin-in fa-fw"></i></span><?php echo $member['linkedin']; ?></a></li>
					                <li class="mb-3"><a class="text-link" href="<?php echo $member['github']; ?>"><span class="fa-container text-center me-2"><i class="fab fa-github-alt fa-fw"></i></span><?php echo $member['github']; ?></a></li>
					                <li><a class="text-link" href="<?php echo $member['name']; ?>"><span class="fa-container text-center me-2"><i class="fas fa-globe"></i></span><?php echo $member['school']; ?></a></li>
							    </ul>
						    </div><!--//secondary-info-->
					    </div><!--//row-->
					    
				    </div><!--//col-->
			    </div><!--//row-->
		    </header>
		    <div class="resume-body p-5">
			    <section class="resume-section summary-section mb-5">
				    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Summary'; ?></h2>
				    <div class="resume-section-content">
                    <?php echo $member['summary']; ?>
				    </div>
			    </section><!--//summary-section-->
			    <div class="row">
				    <div class="col-lg-9">
					    <section class="resume-section experience-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Work Experience'; ?></h2>
							<?php foreach ($member['experience'] as $experience): ?>
						    <div class="resume-section-content">
							    <div class="resume-timeline position-relative">
								    <article class="resume-timeline-item position-relative pb-5">
									    <div class="resume-timeline-item-header mb-2">
										    <div class="d-flex flex-column flex-md-row">
										        <h3 class="resume-position-title font-weight-bold mb-1"><?php echo $experience['position']; ?></h3>
										        <div class="resume-company-name ms-auto"><?php echo $experience['company']; ?></div>
										    	</div><!--//row-->
										    	<div class="resume-position-time"><?php echo $experience['time']; ?></div>
									    		</div><!--//resume-timeline-item-header-->
									    		<div class="resume-timeline-item-desc">
												<?php echo $experience['summary_of_job']; ?>
									    	</div><!--//resume-timeline-item-desc-->
										</div>
										<?php endforeach; ?>
					    </section><!--//projects-section-->
				    </div>
				    <div class="col-lg-3">
					    <section class="resume-section skills-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Skills &amp; Tools'; ?></h2>
						    <div class="resume-section-content">
							<?php foreach ($member['skills'] as $skill): ?>
						        <div class="resume-skill-item">
							        <ul class="list-unstyled mb-4">
								        <li class="mb-2">
								            <div class="resume-skill-name"><?php echo $skill; ?></div>
								        </li>
							        </ul>
						        </div><!--//resume-skill-item-->
							<?php endforeach; ?>
						        <div class="resume-skill-item">
						            <h4 class="resume-skills-cat font-weight-bold"><?php echo 'Others'; ?></h4>
						            <ul class="list-inline">
										<?php foreach ($member['os'] as $os): ?>
							            	<li class="list-inline-item"><span class="badge badge-light"><?php echo $os; ?></span></li>
										<?php endforeach; ?>
						            </ul>
						        </div><!--//resume-skill-item-->
						    </div><!--resume-section-content-->
					    </section><!--//skills-section-->
					    <section class="resume-section education-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Education'; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled">
								    <li class="mb-2">
								        <div class="resume-degree font-weight-bold"><?php echo $member['education']; ?></div>
								        <div class="resume-degree-org"><?php echo $member['edulocation']; ?></div>
								        <div class="resume-degree-time"><?php echo $member['edu_time_period']; ?>
								    </li>
							    </ul>
						    </div>
					    </section><!--//education-section-->
					    <section class="resume-section reference-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Awards'; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled resume-awards-list">
								    <li class="mb-2 ps-4 position-relative">
									<?php foreach ($member['awards'] as $awards): ?>
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo $awards['name']; ?></div>
								        <div class="resume-award-desc"><?php echo $awards['description']; ?></div>
										<?php endforeach; ?>
								    </li>
							    </ul>
						    </div>
					    </section><!--//interests-section-->
					    <section class="resume-section language-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Languages'; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled resume-lang-list">
								<?php foreach ($member['lang'] as $lang): ?>
								    <li class="mb-2"><span class="resume-lang-name font-weight-bold"><?php echo $lang; ?></span> <small class="text-muted font-weight-normal"></small></li>
								<?php endforeach; ?>
							    </ul>
						    </div>
					    </section><!--//language-section-->
					    <section class="resume-section interests-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Interest'; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled">
								<?php foreach ($member['interest'] as $interest): ?>
								    <li class="mb-1"><?php echo $interest; ?></li>
								<?php endforeach; ?>
							    </ul>
						    </div>
					    </section><!--//interests-section-->
					    
				    </div>
			    </div><!--//row-->
				<section class="resume-section experience-section mb-5">
					<h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Projects'; ?></h2>
					<div class="row mt-4">
						<div class="col-md-4">
						<?php foreach ($member['projects'] as $projects): ?>
							<div class="card">
								<img src="<?php echo $projects['img']; ?>" alt="Project 1" class="card-img-top">
								<div class="card-body">
									<h5 class="card-title"><?php echo $projects['name']; ?></h5>
									<p class="card-text"><?php echo $projects['description']; ?></p>
									<a href="<?php echo $projects['link']; ?>"><?php echo $projects['link_name']; ?></a>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
				</section><!--//projects-section-->
		    </div><!--//resume-body-->
	    </div>
    </article> 
    <footer class="footer text-center pt-2 pb-5">
		<a href="<?php echo "Index.php"?>" class="btn btn-secondary"><?php echo "Back to index"?></a>
	    <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
        <small class="copyright">Designed with <span class="sr-only">love</span><i class="fas fa-heart"></i> by Your name</small>
    </footer>
</body>
</html>